import { HttpHeaders, HttpResponse } from "@angular/common/http";
import { Component } from "@angular/core";
import { HttpService } from "../httpService/http.service";

@Component({
  selector: 'app-withCache',
  templateUrl: './withCache.component.html',
  styleUrls: ['./withCache.component.css']
})
export class WithCacheComponent {
  title = 'angular-poc';
  listItems: any[] = [];
  constructor(
    private httpService:HttpService){

  }

  ngOnInit(){
    let headers = new HttpHeaders({'cache':'true'});
    let config={
      headers:headers
    }
    this.httpService.doRequest("/withCache","GET","", config).subscribe((response:any)=>{
      this.listItems = response;
    });
  }

}
