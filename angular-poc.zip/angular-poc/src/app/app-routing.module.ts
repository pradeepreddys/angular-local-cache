import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ClearCacheComponent } from './clearCache/clearCache.component';
import {WithCacheComponent} from './withCache/withCache.component';
import {WithoutCacheComponent} from './withoutCache/withoutCache.component'

const routes: Routes = [
  {
  path:"withCache",
  component: WithCacheComponent

},
{
  path:"withoutCache",
  component: WithoutCacheComponent

},
{
  path:"clearCache",
  component: ClearCacheComponent

}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
