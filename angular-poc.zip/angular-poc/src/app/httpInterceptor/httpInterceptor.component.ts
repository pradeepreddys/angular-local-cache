import {Injectable} from '@angular/core';
import {
	HttpRequest,
	HttpHandler,
	HttpEvent,
	HttpResponse
} from '@angular/common/http';
import {HttpCacheService} from '../httpCacheServices/http-cache.service';
import {from, Observable, of} from 'rxjs';
import {catchError, delay, finalize, tap} from 'rxjs/operators';

/**
 * Intercept all http requests
 * @class {HttpRequestInterceptor}
 */
@Injectable()
export class HttpRequestInterceptor implements HttpRequestInterceptor {

	constructor(
		private _cache: HttpCacheService
	) {}

	intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    let users= new Array(100).fill(0).map((_,i) =>{ return {id : i, empName: `empName ${i}`, city: `hyderabad ${i}`}});
    let cache = request.headers.get("cache") ? true : false;
		if (request.method === 'GET') {
      if(cache){
        let cachedResponse = this._cache.get(request, cache);
        if (cachedResponse) {
          console.log(`Response from cache for ${request.urlWithParams}`, cachedResponse);
          let httpResponse = new HttpResponse({ body: cachedResponse});
          return of(httpResponse);
        }
      }

      let httpResponse = new HttpResponse({ body: users});
      this._cache.put(request, httpResponse, cache);
      this.sleep(5000);
      return of(httpResponse);

    }
    return new Observable<HttpEvent<any>>();

	}

   sleep(milliseconds: number ) {
    const date = Date.now();
    let currentDate = null;
    do {
      currentDate = Date.now();
    } while (currentDate - date < milliseconds);
  }

}


