import {HttpRequest, HttpResponse} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {LocalStorageService} from '../localstorage/localstorage.service';

abstract class HttpCache {
	abstract get(req: HttpRequest<any>, cache:boolean): HttpResponse<any> | null;
	abstract put(req: HttpRequest<any>, res: HttpResponse<any>, cache:boolean): void;
	abstract delete(req: HttpRequest<any>,cache:boolean): boolean;
}

@Injectable({
	providedIn: 'root'
})
export class HttpCacheService implements HttpCache {
	cache: { [key: string]: HttpResponse<any> } = {};

	constructor() {
	}

	/**
	 * Get an item from the cache
	 * @param req
	 */
	get(req: HttpRequest<any>, cache: boolean): any {
		const cachedItem = LocalStorageService.getItem('empData')
		if (cachedItem && cache) {
			return cachedItem;
		}
	}

	/**
	 * Put an item in the cache
	 * @param req
	 * @param res
	 */
	put(req: HttpRequest<any>, res: HttpResponse<any>,cache: boolean): void {
		if (cache) {
      LocalStorageService.setItem('empData', res.body);
		}
	}

	delete(req: HttpRequest<any>, cache:boolean): boolean {
		const cachedRequest = this.get(req, cache);
		let returnVal = false;
		if (cachedRequest) {
			LocalStorageService.removeItem('empData');
			returnVal = true;
		}
		return returnVal;
	}

}
