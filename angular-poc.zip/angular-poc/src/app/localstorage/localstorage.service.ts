export enum LocalStorageTypes {
	LOCAL = 'local',
	SESSION = 'session'
}

export class LocalStorageService {

	/**
	 * Get a localStorage or sessionStorage item value
	 * @param storageType {'local'|'session'}
	 * @param key {string}
	 */
	static getItem(key: string) {
		const val = localStorage.getItem(`angular-poc:${key}`)??"";
		try {
			return JSON.parse(val);
		} catch (e) {
			return val;
		}
	}

	static setItem( key: string, value: any) {
		const val = typeof value === 'string' ? value : JSON.stringify(value);
		localStorage.setItem(`angular-poc:${key}`, val);
	}

	static removeItem(key: string) {
		localStorage.removeItem(`angular-poc:${key}`);
	}

}
