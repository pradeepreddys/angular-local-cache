import { Component } from "@angular/core";
import { LocalStorageService } from "../localstorage/localstorage.service";

@Component({
  selector: 'app-clearCache',
  templateUrl: './clearCache.component.html'
})
export class ClearCacheComponent {
  title = 'angular-poc';
  listItems: any[] = [];


  ngOnInit(){
    LocalStorageService.removeItem('empData');
  }
}
