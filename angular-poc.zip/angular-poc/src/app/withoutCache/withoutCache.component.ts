import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Component } from "@angular/core";
import {HttpRequestConfig, HttpService} from "../httpService/http.service"

@Component({
  selector: 'app-withCache',
  templateUrl: './withoutCache.component.html',
  styleUrls: ['./withoutCache.component.css']
})
export class WithoutCacheComponent {
  title = 'angular-poc';
  listItems: any[] = [];

  constructor(
    private httpService:HttpService){

  }

  ngOnInit(){
    let headers = new HttpHeaders();
    let config={
      headers:headers
    }
    this.httpService.doRequest("/withoutCache","GET","", config).subscribe((response:any)=>{
      this.listItems = response;
    });
  }
}
