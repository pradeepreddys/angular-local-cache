import {HttpClient, HttpErrorResponse, HttpHeaders, HttpParams, HttpResponse} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {Router} from '@angular/router';
import {Observable} from 'rxjs';
import {catchError, map} from 'rxjs/operators';

@Injectable({
	providedIn: 'root'
})
export class HttpService {

	constructor(
		private _http: HttpClient
	) {}

	doRequest(apiUrl: string, method: string, body?: any, config?: any) {
		if (method === 'GET') {
			if (!config && body) {
				config = {observe: body};
			}else if (config && body) {
				config.observe = body;
			}
		}
		return this._http.get(apiUrl, config)
	}

}

export interface HttpRequestConfig {
	headers?: HttpHeaders | {
		[header: string]: string | string[];
	};
	observe?: 'body';
	params?: HttpParams | {
		[param: string]: string | string[];
	};
	reportProgress?: boolean;
	responseType?: 'json';
	withCredentials?: boolean;
}
