import { CommonModule } from '@angular/common';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpCacheService } from './httpCacheServices/http-cache.service';
import { HttpRequestInterceptor } from './httpInterceptor/httpInterceptor.component';
import { HttpService } from './httpService/http.service';
import { LocalStorageService } from './localstorage/localstorage.service';
import { WithCacheComponent } from './withCache/withCache.component';
import { WithoutCacheComponent } from './withoutCache/withoutCache.component';

@NgModule({
  declarations: [
    AppComponent,
    WithCacheComponent,
    WithoutCacheComponent
  ],
  imports: [
    BrowserModule,
    CommonModule,
    AppRoutingModule,
    HttpClientModule

  ],
  providers: [
    {provide: HTTP_INTERCEPTORS, useClass: HttpRequestInterceptor, multi: true},
		HttpCacheService,
		HttpService,
		LocalStorageService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
